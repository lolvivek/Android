# TaskBell — Android APK Project

Package ID: `com.taskbell.app`
Version: `1.0.0` (code `1`)
Min SDK: Android `24` | Target SDK: Android `35`

## Option 1: Build APK in Android Studio (Local)
1. Extract this archive into a folder.
2. Open **Android Studio** -> **Open** -> select this extracted folder.
3. Let Gradle sync finish, then click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
4. Find your APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Option 2: Build APK via Command Line
```bash
gradle assembleDebug
```
(If you prefer Gradle Wrapper, run `gradle wrapper` once or open in Android Studio.)

## Option 3: Automatic Cloud APK via GitHub Actions
1. Push this extracted folder to a GitHub repository.
2. Open the **Actions** tab and run **Build Android APK**.
3. Download the compiled `app-debug.apk` artifact directly to your Android phone.
